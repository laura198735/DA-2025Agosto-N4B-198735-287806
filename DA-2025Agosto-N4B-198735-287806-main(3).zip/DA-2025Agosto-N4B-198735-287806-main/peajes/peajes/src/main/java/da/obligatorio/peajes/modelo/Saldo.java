package da.obligatorio.peajes.modelo;

public class Saldo {
    public double montoInicial;

    

    public Saldo(double montoInicial) {
        this.montoInicial = montoInicial;
    }

    public double getMontoInicial() {
        return montoInicial;
    }

    public void setMontoInicial(double montoInicial) {
        this.montoInicial = montoInicial;
    }


}
