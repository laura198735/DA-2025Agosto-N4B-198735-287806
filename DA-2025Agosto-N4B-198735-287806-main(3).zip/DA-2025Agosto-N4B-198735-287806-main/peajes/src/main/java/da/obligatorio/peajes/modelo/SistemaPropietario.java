package da.obligatorio.peajes.modelo;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class SistemaPropietario {
    private ArrayList<Usuario> usuarios = new ArrayList();
}
