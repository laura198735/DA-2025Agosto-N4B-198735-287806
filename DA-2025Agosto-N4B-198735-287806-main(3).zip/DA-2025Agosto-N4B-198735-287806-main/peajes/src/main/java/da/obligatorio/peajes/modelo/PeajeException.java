package da.obligatorio.peajes.modelo;

public class PeajeException extends Exception {
    public PeajeException(String message) {
        super(message);
    }
}
